<?php

/**
 * 修改菜单
 */
add_hook('ClientAreaPrimaryNavbar', 1, function($primaryNavbar) {

    # 语言文件
    GLOBAL $MODLANG;
    if(empty($MODLANG)){
        require_once __DIR__.'/../../servers/TRUSTOCEANSSL/libary/languageLoader.php';
        $langLoader = new lanaguageLoader($_SESSION);
        $MODLANG = $langLoader->loading();
    }

    $newMenu0 = $primaryNavbar->addChild(
        'trustoceanMySSLCertificate',
        array(
            'name' => 'list-certificate',
            'label' => "My SSL",
            'uri' => '/index.php?m=TrustOceanSSLAdmin',
            'order' => 15,
            'target' => '_blank',
            'icon' => 'fa fa-lock',
        )
    );
});