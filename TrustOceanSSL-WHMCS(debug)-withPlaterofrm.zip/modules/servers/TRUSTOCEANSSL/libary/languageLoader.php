<?php

class lanaguageLoader{

    private  $lang;

    function __construct($vars)
    {
        $currentLang = $vars['Language'];
        $_LANG = [];
        $langDirBase =  __DIR__.'/../lang/';
        $file = "english.php";
        if($currentLang == ""){
            $file = 'english.php';
        }elseif ($currentLang == "chinese"){
            $file = 'chinese.php';
        }elseif(file_exists(__DIR__.'/../lang/'.strtolower($currentLang))){
            $file = strtolower($currentLang).'php';
        }else{
            $file = 'english.php';
        }
        require_once $langDirBase.$file;
        $this->lang = $_LANG;
    }

    public function loading(){
        return $this->lang;
    }
}