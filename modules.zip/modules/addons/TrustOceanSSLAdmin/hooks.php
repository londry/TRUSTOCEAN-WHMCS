<?php
/**
 * 这里可以添加全局hook, 仅当激活TrustOceanSSLAdmin模块生效时才会被调用
 * 参考可用的Hooks: https://developers.whmcs.com/hooks/hook-index/
 */


