// language file for Chinese Simple
MODLANG = new Array();
MODLANG.trustoceanssl = [];
MODLANG.trustoceanssl.enroll = [];
MODLANG.trustoceanssl.enroll.ajax = [];
MODLANG.trustoceanssl.enroll.status = [];
MODLANG.enroll = [];
MODLANG.enroll.status = [];

MODLANG.trustoceanssl.enroll.ajax.systemmessage  = 'Notification';
MODLANG.trustoceanssl.enroll.ajax.ok  = 'OK';
MODLANG.trustoceanssl.enroll.ajax.dcvsuccess  = 'Successfully, Order status has been updated! you can update verification status every 5 minutes.';

MODLANG.trustoceanssl.dcvfetchsuccess = 'Successfully, your order status has beed updated, you can fetch the verification status every 5 minutes.';
MODLANG.trustoceanssl.submitsuccess = 'Congratulations, your order has been uploaded!';
MODLANG.trustoceanssl.certissued = 'Congratulations, your SSL has beed issued and active！';
MODLANG.trustoceanssl.submitreissue = 'Successfully, your reissue information has beed saved！';
MODLANG.trustoceanssl.removing = "Removing";
MODLANG.trustoceanssl.csrsaved = "Successfully, your CSR code has beed saved!";
MODLANG.trustoceanssl.certinfosaved = "Successfully, your certificate request information has been saved!";
MODLANG.enroll.status.verified = "Verified";
MODLANG.enroll.status.processing = "Processing"; 
MODLANG.enroll.status.emailsent = "Email Sent";
MODLANG.enroll.status.selectall = "Select For ALL";
MODLANG.enroll.status.selectdcvmethodforall = "Use the selected method for all un verified domains";